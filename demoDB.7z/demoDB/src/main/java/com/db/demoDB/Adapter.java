package com.db.demoDB;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan("com")
public class Adapter extends WebMvcConfigurerAdapter {

	public Adapter() {
		// TODO Auto-generated constructor stub
	}
	
	public void getDefaultServlet(DefaultServletHandlerConfigurer config)
	{
		config.enable();
	}

	
	@Bean
	public InternalResourceViewResolver getView()
	{
		InternalResourceViewResolver inv = new InternalResourceViewResolver();
		inv.setPrefix("/WEB-INF/pages/");
		inv.setSuffix(".jsp");
		
		return inv;
		
	}
	
	@Bean
	@ConfigurationProperties("spring.datasource")
	public DataSource getDataSrc()
	{
		return DataSourceBuilder.create().build();
	}
	

	
}
