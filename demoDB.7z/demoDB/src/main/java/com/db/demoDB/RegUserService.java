package com.db.demoDB;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class RegUserService {

	@Autowired
	public UserRepo userRepo;
	
	public void save(User user)
	{
		userRepo.save(user);
	}
	

}
