package com.db.demoDB;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	@Autowired
	RegUserService reg;

	@RequestMapping("/login")
	public ModelAndView login(@RequestParam("user") String user,@RequestParam("pwd") String pwd )
	{
		
		return new ModelAndView("login");
	}
	
	
	
	@RequestMapping("/reg")
	public ModelAndView regClick()
	{
		return new ModelAndView("reg","user",new User());
	}
	
	
	
	@RequestMapping("/save")
	public ModelAndView save(@ModelAttribute("user")User user,BindingResult bind)
	{
		ModelAndView mv = new ModelAndView("login" , "user" ,user);
		System.out.println("user object:::"+user.getUserName());
		
		user.setUserId("1");
		reg.save(user);
		return mv;
	}
	
	
}
