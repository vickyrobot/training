@RestController
class Hello{

@RequestMapping("/")
public Strig say()
{
return "hi kdfsdkjf";
}

}