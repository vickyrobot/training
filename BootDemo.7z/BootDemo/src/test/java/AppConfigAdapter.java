


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;


@Configuration
@EnableWebMvc
public class AppConfigAdapter extends WebMvcConfigurerAdapter{

	public AppConfigAdapter() {
	}
	
	public void getDefaultServlet(DefaultServletHandlerConfigurer config)
	{
		config.enable();
	}
	
	@Bean
	public InternalResourceViewResolver getView()
	{
		InternalResourceViewResolver inv = new InternalResourceViewResolver();
		inv.setPrefix("/WEB-INF/pages/");
		inv.setSuffix(".jsp");
		
		return inv;
		
	}

}
